# Canonical decisions / audit history
- 2026-10-24: Owner clarified deliverable is a **production-directed storyboard/script/images/transitions/capture package**, not a rendered video; default MP4 prohibited.
- 2026-10-24: **Two-image Midjourney transitions** are primary; single-image animations acceptable. Real people use real stills; deterministic graphics for exact text, maps, poll, market and six TIP grades. The user can capture footage and assemble in Premiere Pro.
- 2026-10-24: Story/script written and approved before deciding images; creative should be narratively motivated, not generated from 18 pre-existing Florida frames.
- 2026-10-24: Persistent owner-computer local Claude repository is canonical; this ZIP is transport. Claude must create actual startup references and install versioned skills and tests before calling workflow locked.
- 2026-10-24: Lean Story Scout and factcheck only the claims actually used; finance/FEC bulk data not mandatory. Six approved article formats retained; Governor/Senate/House state scope only.
- 2026-10-24: Michigan is next end-to-end test **after** installation; Florida script will be finalized in ChatGPT separately.
- 2026-10-28 (install): The Production Lock v2.0 was installed into `docs/production/` of the existing LLF repository. `llf-video-director` 2.0.0 is the single video entry point; `llf-video-storyboard` is a legacy alias (2.0.0) and `llf-footage-scout` a sub-procedure (1.1.0, no download by default, the owner captures footage).
- 2026-10-28 (install): The fixed 18 x 5-second storyboard and its builder remain only as the Florida historical example, fenced from other states; new states use `tools/video/scene_pack.py` (script-led timing, `SCENES.csv`, `ASSETS.csv`, `TRANSITIONS.csv`). The legacy builder gained `--render-video --authorization` (records the request, renders nothing) and a guard that no video file is left in its output.
- 2026-10-28 (install): Canonical workflow lanes `production:<state>-<year>` (12 stages) and `render:<state>-<year>` were added to `tools/workflow/transitions.py`; publishing, deploying and rendering stages require a recorded owner authorization and fact-check stages a reviewer other than the actor. The older `story:` and `video:` lanes stay valid for existing entries.
- 2026-10-28 (install): The Illinois discovery material was preserved exactly as returned. The State Board of Elections 403 is recorded as a specific data-access limitation (`docs/production/DATA_ACCESS_LIMITATIONS.md`, `docs/illinois/DATA_ACCESS_LIMITATIONS.md`); the roster is not claimed complete or official.
- 2026-10-28 (install): Michigan was not started, no page was published or uploaded, no video was rendered and no new research was done during the install.

## 2026-10-28 owner dispositions of the install's open issues
1. Florida video uses an older script: keep flagged as legacy; it must not overwrite the finalized creative work.
2. Midjourney settings unverified: address when producing the next video, not now.
3. Older footage downloads: preserve existing assets and rights records; not revisited during Illinois production.
4. Multiple workflow lanes: use the `production:` lane going forward.
5. Illinois official roster inaccessible: must be resolved before claiming the Illinois State of the Race directory is complete.
6. `seed_backfill.py` deletes ledger history: do not run it; preserve Illinois research and production state.
